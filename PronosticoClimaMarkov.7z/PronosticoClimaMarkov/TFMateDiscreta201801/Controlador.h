#pragma once
#include "ControladorValores.h"
using namespace System::Drawing;

class CControlador
{
public:
	CControlador();
	~CControlador();

	CCV* getCV();

	void reiniciarCV();

private:
	CCV* cv;
};

CControlador::CControlador()
{
	cv = new CCV();
}

CControlador::~CControlador()
{
}

CCV* CControlador::getCV() { return cv; }

void CControlador::reiniciarCV() { cv = new CCV(); }