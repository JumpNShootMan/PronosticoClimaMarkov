#include "Formulario.h"

using namespace System::Drawing;
using namespace TFMateDiscreta201801;

int main() {

	Application::EnableVisualStyles();
	Application::Run(gcnew Formulario());

	return 0;
}