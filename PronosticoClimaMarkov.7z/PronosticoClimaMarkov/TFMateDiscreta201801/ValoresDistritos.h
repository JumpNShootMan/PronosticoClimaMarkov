#pragma once

class CVD
{
public:
	CVD();
	~CVD();

	int* getarrValAte();
	int* getarrValSantiago_de_Surco();
	int* getarrValChaclacayo();
	int* getarrValLa_Molina();
	int* getarrValSan_Isidro();

private:
	int* arrValAte;
	int* arrValSantiago_de_Surco;
	int* arrValChaclacayo;
	int* arrValLa_Molina;
	int* arrValSan_Isidro;
};

CVD::CVD()
{
	//INICIALIZAR DISTRITOS LIMA
	arrValAte = new int[80];
	{
		arrValAte[0] = 0;
		arrValAte[1] = 0;
		arrValAte[2] = 0;
		arrValAte[3] = 0;
		arrValAte[4] = 0;
		arrValAte[5] = 0;
		arrValAte[6] = 0;
		arrValAte[7] = 0;
		arrValAte[8] = 0;
		arrValAte[9] = 0;

		arrValAte[10] = 0;
		arrValAte[11] = 0;
		arrValAte[12] = 0;
		arrValAte[13] = 0;
		arrValAte[14] = 0;
		arrValAte[15] = 0;
		arrValAte[16] = 0;
		arrValAte[17] = 1;
		arrValAte[18] = 0;
		arrValAte[19] = 0;

		arrValAte[20] = 0;
		arrValAte[21] = 0;
		arrValAte[22] = 2;
		arrValAte[23] = 3;
		arrValAte[24] = 0;
		arrValAte[25] = 0;
		arrValAte[26] = 1;
		arrValAte[27] = 0;
		arrValAte[28] = 0;
		arrValAte[29] = 1;

		arrValAte[30] = 1;
		arrValAte[31] = 2;
		arrValAte[32] = 0;
		arrValAte[33] = 0;
		arrValAte[34] = 0;
		arrValAte[35] = 0;
		arrValAte[36] = 0;
		arrValAte[37] = 1;
		arrValAte[38] = 0;
		arrValAte[39] = 2;

		arrValAte[40] = 2;
		arrValAte[41] = 1;
		arrValAte[42] = 1;
		arrValAte[43] = 1;
		arrValAte[44] = 1;
		arrValAte[45] = 2;
		arrValAte[46] = 1;
		arrValAte[47] = 2;
		arrValAte[48] = 0;
		arrValAte[49] = 1;

		arrValAte[50] = 1;
		arrValAte[51] = 2;
		arrValAte[52] = 1;
		arrValAte[53] = 2;
		arrValAte[54] = 0;
		arrValAte[55] = 0;
		arrValAte[56] = 1;
		arrValAte[57] = 2;
		arrValAte[58] = 1;
		arrValAte[59] = 0;

		arrValAte[60] = 1;
		arrValAte[61] = 1;
		arrValAte[62] = 2;
		arrValAte[63] = 2;
		arrValAte[64] = 1;
		arrValAte[65] = 2;
		arrValAte[66] = 2;
		arrValAte[67] = 2;
		arrValAte[68] = 3;
		arrValAte[69] = 3;

		arrValAte[70] = 3;
		arrValAte[71] = 3;
		arrValAte[72] = 3;
		arrValAte[73] = 2;
		arrValAte[74] = 2;
		arrValAte[75] = 3;
		arrValAte[76] = 3;
		arrValAte[77] = 3;
		arrValAte[78] = 3;
		arrValAte[79] = 0;
	}
	arrValChaclacayo = new int[80];
	{
		arrValChaclacayo[0] = 0;
		arrValChaclacayo[1] = 0;
		arrValChaclacayo[2] = 0;
		arrValChaclacayo[3] = 0;
		arrValChaclacayo[4] = 0;
		arrValChaclacayo[5] = 0;
		arrValChaclacayo[6] = 0;
		arrValChaclacayo[7] = 0;
		arrValChaclacayo[8] = 0;
		arrValChaclacayo[9] = 0;

		arrValChaclacayo[10] = 0;
		arrValChaclacayo[11] = 0;
		arrValChaclacayo[12] = 0;
		arrValChaclacayo[13] = 0;
		arrValChaclacayo[14] = 0;
		arrValChaclacayo[15] = 0;
		arrValChaclacayo[16] = 0;
		arrValChaclacayo[17] = 0;
		arrValChaclacayo[18] = 0;
		arrValChaclacayo[19] = 0;

		arrValChaclacayo[20] = 0;
		arrValChaclacayo[21] = 0;
		arrValChaclacayo[22] = 0;
		arrValChaclacayo[23] = 1;
		arrValChaclacayo[24] = 0;
		arrValChaclacayo[25] = 0;
		arrValChaclacayo[26] = 0;
		arrValChaclacayo[27] = 0;
		arrValChaclacayo[28] = 0;
		arrValChaclacayo[29] = 0;

		arrValChaclacayo[30] = 0;
		arrValChaclacayo[31] = 0;
		arrValChaclacayo[32] = 0;
		arrValChaclacayo[33] = 0;
		arrValChaclacayo[34] = 0;
		arrValChaclacayo[35] = 0;
		arrValChaclacayo[36] = 0;
		arrValChaclacayo[37] = 1;
		arrValChaclacayo[38] = 0;
		arrValChaclacayo[39] = 0;

		arrValChaclacayo[40] = 0;
		arrValChaclacayo[41] = 0;
		arrValChaclacayo[42] = 2;
		arrValChaclacayo[43] = 3;
		arrValChaclacayo[44] = 0;
		arrValChaclacayo[45] = 0;
		arrValChaclacayo[46] = 0;
		arrValChaclacayo[47] = 0;
		arrValChaclacayo[48] = 0;
		arrValChaclacayo[49] = 1;

		arrValChaclacayo[50] = 1;
		arrValChaclacayo[51] = 1;
		arrValChaclacayo[52] = 0;
		arrValChaclacayo[53] = 0;
		arrValChaclacayo[54] = 0;
		arrValChaclacayo[55] = 0;
		arrValChaclacayo[56] = 0;
		arrValChaclacayo[57] = 1;
		arrValChaclacayo[58] = 0;
		arrValChaclacayo[59] = 1;

		arrValChaclacayo[60] = 1;
		arrValChaclacayo[61] = 1;
		arrValChaclacayo[62] = 1;
		arrValChaclacayo[63] = 1;
		arrValChaclacayo[64] = 1;
		arrValChaclacayo[65] = 2;
		arrValChaclacayo[66] = 1;
		arrValChaclacayo[67] = 2;
		arrValChaclacayo[68] = 0;
		arrValChaclacayo[69] = 1;

		arrValChaclacayo[70] = 2;
		arrValChaclacayo[71] = 2;
		arrValChaclacayo[72] = 2;
		arrValChaclacayo[73] = 2;
		arrValChaclacayo[74] = 0;
		arrValChaclacayo[75] = 1;
		arrValChaclacayo[76] = 1;
		arrValChaclacayo[77] = 2;
		arrValChaclacayo[78] = 2;
		arrValChaclacayo[79] = 3;
	}
	arrValLa_Molina = new int[80];
	{
		arrValLa_Molina[0] = 0;
		arrValLa_Molina[1] = 0;
		arrValLa_Molina[2] = 0;
		arrValLa_Molina[3] = 0;
		arrValLa_Molina[4] = 0;
		arrValLa_Molina[5] = 0;
		arrValLa_Molina[6] = 0;
		arrValLa_Molina[7] = 0;
		arrValLa_Molina[8] = 0;
		arrValLa_Molina[9] = 0;

		arrValLa_Molina[10] = 0;
		arrValLa_Molina[11] = 0;
		arrValLa_Molina[12] = 0;
		arrValLa_Molina[13] = 0;
		arrValLa_Molina[14] = 0;
		arrValLa_Molina[15] = 0;
		arrValLa_Molina[16] = 0;
		arrValLa_Molina[17] = 1;
		arrValLa_Molina[18] = 0;
		arrValLa_Molina[19] = 0;

		arrValLa_Molina[20] = 0;
		arrValLa_Molina[21] = 0;
		arrValLa_Molina[22] = 2;
		arrValLa_Molina[23] = 3;
		arrValLa_Molina[24] = 0;
		arrValLa_Molina[25] = 0;
		arrValLa_Molina[26] = 1;
		arrValLa_Molina[27] = 0;
		arrValLa_Molina[28] = 0;
		arrValLa_Molina[29] = 1;

		arrValLa_Molina[30] = 1;
		arrValLa_Molina[31] = 2;
		arrValLa_Molina[32] = 0;
		arrValLa_Molina[33] = 0;
		arrValLa_Molina[34] = 0;
		arrValLa_Molina[35] = 0;
		arrValLa_Molina[36] = 0;
		arrValLa_Molina[37] = 1;
		arrValLa_Molina[38] = 0;
		arrValLa_Molina[39] = 2;

		arrValLa_Molina[40] = 2;
		arrValLa_Molina[41] = 1;
		arrValLa_Molina[42] = 1;
		arrValLa_Molina[43] = 1;
		arrValLa_Molina[44] = 1;
		arrValLa_Molina[45] = 2;
		arrValLa_Molina[46] = 1;
		arrValLa_Molina[47] = 2;
		arrValLa_Molina[48] = 0;
		arrValLa_Molina[49] = 1;

		arrValLa_Molina[50] = 1;
		arrValLa_Molina[51] = 2;
		arrValLa_Molina[52] = 1;
		arrValLa_Molina[53] = 2;
		arrValLa_Molina[54] = 0;
		arrValLa_Molina[55] = 0;
		arrValLa_Molina[56] = 1;
		arrValLa_Molina[57] = 2;
		arrValLa_Molina[58] = 1;
		arrValLa_Molina[59] = 0;

		arrValLa_Molina[60] = 1;
		arrValLa_Molina[61] = 1;
		arrValLa_Molina[62] = 2;
		arrValLa_Molina[63] = 2;
		arrValLa_Molina[64] = 1;
		arrValLa_Molina[65] = 2;
		arrValLa_Molina[66] = 2;
		arrValLa_Molina[67] = 2;
		arrValLa_Molina[68] = 3;
		arrValLa_Molina[69] = 3;

		arrValLa_Molina[70] = 3;
		arrValLa_Molina[71] = 3;
		arrValLa_Molina[72] = 3;
		arrValLa_Molina[73] = 2;
		arrValLa_Molina[74] = 2;
		arrValLa_Molina[75] = 3;
		arrValLa_Molina[76] = 3;
		arrValLa_Molina[77] = 3;
		arrValLa_Molina[78] = 3;
		arrValLa_Molina[79] = 0;
	}
	arrValSan_Isidro = new int[80];
	{
		arrValSan_Isidro[0] = 0;
		arrValSan_Isidro[1] = 0;
		arrValSan_Isidro[2] = 0;
		arrValSan_Isidro[3] = 0;
		arrValSan_Isidro[4] = 0;
		arrValSan_Isidro[5] = 0;
		arrValSan_Isidro[6] = 0;
		arrValSan_Isidro[7] = 0;
		arrValSan_Isidro[8] = 0;
		arrValSan_Isidro[9] = 0;

		arrValSan_Isidro[10] = 0;
		arrValSan_Isidro[11] = 0;
		arrValSan_Isidro[12] = 0;
		arrValSan_Isidro[13] = 0;
		arrValSan_Isidro[14] = 0;
		arrValSan_Isidro[15] = 0;
		arrValSan_Isidro[16] = 0;
		arrValSan_Isidro[17] = 1;
		arrValSan_Isidro[18] = 0;
		arrValSan_Isidro[19] = 0;

		arrValSan_Isidro[20] = 0;
		arrValSan_Isidro[21] = 0;
		arrValSan_Isidro[22] = 2;
		arrValSan_Isidro[23] = 3;
		arrValSan_Isidro[24] = 0;
		arrValSan_Isidro[25] = 0;
		arrValSan_Isidro[26] = 1;
		arrValSan_Isidro[27] = 0;
		arrValSan_Isidro[28] = 0;
		arrValSan_Isidro[29] = 1;

		arrValSan_Isidro[30] = 1;
		arrValSan_Isidro[31] = 2;
		arrValSan_Isidro[32] = 0;
		arrValSan_Isidro[33] = 0;
		arrValSan_Isidro[34] = 0;
		arrValSan_Isidro[35] = 0;
		arrValSan_Isidro[36] = 0;
		arrValSan_Isidro[37] = 1;
		arrValSan_Isidro[38] = 0;
		arrValSan_Isidro[39] = 2;

		arrValSan_Isidro[40] = 2;
		arrValSan_Isidro[41] = 1;
		arrValSan_Isidro[42] = 1;
		arrValSan_Isidro[43] = 1;
		arrValSan_Isidro[44] = 1;
		arrValSan_Isidro[45] = 2;
		arrValSan_Isidro[46] = 1;
		arrValSan_Isidro[47] = 2;
		arrValSan_Isidro[48] = 0;
		arrValSan_Isidro[49] = 1;

		arrValSan_Isidro[50] = 1;
		arrValSan_Isidro[51] = 2;
		arrValSan_Isidro[52] = 1;
		arrValSan_Isidro[53] = 2;
		arrValSan_Isidro[54] = 0;
		arrValSan_Isidro[55] = 0;
		arrValSan_Isidro[56] = 1;
		arrValSan_Isidro[57] = 2;
		arrValSan_Isidro[58] = 1;
		arrValSan_Isidro[59] = 0;

		arrValSan_Isidro[60] = 1;
		arrValSan_Isidro[61] = 1;
		arrValSan_Isidro[62] = 2;
		arrValSan_Isidro[63] = 2;
		arrValSan_Isidro[64] = 1;
		arrValSan_Isidro[65] = 2;
		arrValSan_Isidro[66] = 2;
		arrValSan_Isidro[67] = 2;
		arrValSan_Isidro[68] = 3;
		arrValSan_Isidro[69] = 3;

		arrValSan_Isidro[70] = 3;
		arrValSan_Isidro[71] = 3;
		arrValSan_Isidro[72] = 3;
		arrValSan_Isidro[73] = 2;
		arrValSan_Isidro[74] = 2;
		arrValSan_Isidro[75] = 3;
		arrValSan_Isidro[76] = 3;
		arrValSan_Isidro[77] = 3;
		arrValSan_Isidro[78] = 3;
		arrValSan_Isidro[79] = 0;
	}
	arrValSantiago_de_Surco = new int[80];
	{
		arrValSantiago_de_Surco[0] = 0;
		arrValSantiago_de_Surco[1] = 0;
		arrValSantiago_de_Surco[2] = 0;
		arrValSantiago_de_Surco[3] = 0;
		arrValSantiago_de_Surco[4] = 0;
		arrValSantiago_de_Surco[5] = 0;
		arrValSantiago_de_Surco[6] = 0;
		arrValSantiago_de_Surco[7] = 0;
		arrValSantiago_de_Surco[8] = 0;
		arrValSantiago_de_Surco[9] = 0;

		arrValSantiago_de_Surco[10] = 0;
		arrValSantiago_de_Surco[11] = 0;
		arrValSantiago_de_Surco[12] = 0;
		arrValSantiago_de_Surco[13] = 0;
		arrValSantiago_de_Surco[14] = 0;
		arrValSantiago_de_Surco[15] = 0;
		arrValSantiago_de_Surco[16] = 0;
		arrValSantiago_de_Surco[17] = 1;
		arrValSantiago_de_Surco[18] = 0;
		arrValSantiago_de_Surco[19] = 0;

		arrValSantiago_de_Surco[20] = 0;
		arrValSantiago_de_Surco[21] = 0;
		arrValSantiago_de_Surco[22] = 2;
		arrValSantiago_de_Surco[23] = 3;
		arrValSantiago_de_Surco[24] = 0;
		arrValSantiago_de_Surco[25] = 0;
		arrValSantiago_de_Surco[26] = 1;
		arrValSantiago_de_Surco[27] = 0;
		arrValSantiago_de_Surco[28] = 0;
		arrValSantiago_de_Surco[29] = 1;

		arrValSantiago_de_Surco[30] = 1;
		arrValSantiago_de_Surco[31] = 2;
		arrValSantiago_de_Surco[32] = 0;
		arrValSantiago_de_Surco[33] = 0;
		arrValSantiago_de_Surco[34] = 0;
		arrValSantiago_de_Surco[35] = 0;
		arrValSantiago_de_Surco[36] = 0;
		arrValSantiago_de_Surco[37] = 1;
		arrValSantiago_de_Surco[38] = 0;
		arrValSantiago_de_Surco[39] = 2;

		arrValSantiago_de_Surco[40] = 2;
		arrValSantiago_de_Surco[41] = 1;
		arrValSantiago_de_Surco[42] = 1;
		arrValSantiago_de_Surco[43] = 1;
		arrValSantiago_de_Surco[44] = 1;
		arrValSantiago_de_Surco[45] = 2;
		arrValSantiago_de_Surco[46] = 1;
		arrValSantiago_de_Surco[47] = 2;
		arrValSantiago_de_Surco[48] = 0;
		arrValSantiago_de_Surco[49] = 1;

		arrValSantiago_de_Surco[50] = 1;
		arrValSantiago_de_Surco[51] = 2;
		arrValSantiago_de_Surco[52] = 1;
		arrValSantiago_de_Surco[53] = 2;
		arrValSantiago_de_Surco[54] = 0;
		arrValSantiago_de_Surco[55] = 0;
		arrValSantiago_de_Surco[56] = 1;
		arrValSantiago_de_Surco[57] = 2;
		arrValSantiago_de_Surco[58] = 1;
		arrValSantiago_de_Surco[59] = 0;

		arrValSantiago_de_Surco[60] = 1;
		arrValSantiago_de_Surco[61] = 1;
		arrValSantiago_de_Surco[62] = 2;
		arrValSantiago_de_Surco[63] = 2;
		arrValSantiago_de_Surco[64] = 1;
		arrValSantiago_de_Surco[65] = 2;
		arrValSantiago_de_Surco[66] = 2;
		arrValSantiago_de_Surco[67] = 2;
		arrValSantiago_de_Surco[68] = 3;
		arrValSantiago_de_Surco[69] = 3;

		arrValSantiago_de_Surco[70] = 3;
		arrValSantiago_de_Surco[71] = 3;
		arrValSantiago_de_Surco[72] = 3;
		arrValSantiago_de_Surco[73] = 2;
		arrValSantiago_de_Surco[74] = 2;
		arrValSantiago_de_Surco[75] = 3;
		arrValSantiago_de_Surco[76] = 3;
		arrValSantiago_de_Surco[77] = 3;
		arrValSantiago_de_Surco[78] = 3;
		arrValSantiago_de_Surco[79] = 0;
	}

}

CVD::~CVD()
{
}

int* CVD::getarrValAte() { return arrValAte; }
int* CVD::getarrValChaclacayo() { return arrValChaclacayo; }
int* CVD::getarrValLa_Molina() { return arrValLa_Molina; }
int* CVD::getarrValSan_Isidro() { return arrValSan_Isidro; }
int* CVD::getarrValSantiago_de_Surco() { return arrValSantiago_de_Surco; }