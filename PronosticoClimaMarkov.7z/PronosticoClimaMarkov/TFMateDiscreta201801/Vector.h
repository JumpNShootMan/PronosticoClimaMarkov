#pragma once

class CVector
{
public:
	CVector();
	~CVector();

	float getvs();
	float getvps();
	float getvpn();
	float getvn();

	void setvs(float o);
	void setvps(float o);
	void setvpn(float o);
	void setvn(float o);

	CVector(float vs, float vps, float vpn, float vn);

	//FUNCIONES DE LA L�GICA
	void calVectorSig
	(float sRs, float sRps, float sRpn, float sRn, float psRs, float psRps, float psRpn, float psRn, float pnRs, float pnRps, float pnRpn, float pnRn, float nRs, float nRps, float nRpn, float nRn);
	int calMayor();


private:
	float vs;
	float vps;
	float vpn;
	float vn;
};

CVector::CVector()
{
	vs = 0;
	vps = 0;
	vpn = 0;
	vn = 0;
}

CVector::~CVector()
{
}

float CVector::getvs() { return vs; }
float CVector::getvps() { return vps; }
float CVector::getvpn() { return vpn; }
float CVector::getvn() { return vn; }

void CVector::setvs(float o) { vs = o; }
void CVector::setvps(float o) { vps = o; }
void CVector::setvpn(float o) { vpn = o; }
void CVector::setvn(float o) { vn = o; }

CVector::CVector(float vs, float vps, float vpn, float vn) {
	this->vs = vs;
	this->vps = vps;
	this->vpn = vpn;
	this->vn = vn;
}
void CVector::calVectorSig(float sRs, float sRps, float sRpn, float sRn, float psRs, float psRps, float psRpn, float psRn, float pnRs, float pnRps, float pnRpn, float pnRn, float nRs, float nRps, float nRpn, float nRn) {

	float auxvs, auxvps, auxvpn, auxvn;

	auxvs = vs*sRs + vps*psRs + vpn*pnRs + vn*nRs;
	auxvps = vs*sRps + vps*psRps + vpn*pnRps + vn*nRps;
	auxvpn = vs*sRpn + vps*psRpn + vpn*pnRpn + vn*nRpn;
	auxvn = vs*sRn + vps*psRn + vpn*pnRn + vn*nRn;

	vs = auxvs;
	vps = auxvps;
	vpn = auxvpn;
	vn = auxvn;

}
int CVector::calMayor() {
	

	////metodo 3
	/*float arreglo[4] = { vs, vps, vpn, vn };
	float temp = 0;

	for (int i = 0; i<5; i++)
	{
		if (arreglo[i]>=temp)
			temp = arreglo[i];
	}
	if (temp == vs)return 0;
	if (temp == vps)return 1;
	if (temp == vpn)return 2;
	if (temp == vn)return 3;*/

	////metodo 2
	/*bool mayor1;
	if (vs >= vpn) mayor1 = true; else mayor1 = false;




	if (vs >= vps && vs >= vpn && vs >= vn) return 0;
	if (vps >= vs && vps >= vpn && vps >= vn) return 1;
	if (vpn >= vs && vpn >= vps && vpn >= vn)return 2;*/


	////metodo 1
	bool mayor1, mayor2;
	if (vs >= vps) mayor1 = true; else mayor1 = false;
	if (vpn >= vn) mayor2 = true; else mayor2 = false;

	if (mayor1 == true && mayor2 == true) { if (vs >= vpn) return 0; else return 2; }
	if (mayor1 == true && mayor2 == false) { if (vs >= vn) return 0; else return 3; }
	if (mayor1 == false && mayor2 == true) { if (vps >= vpn) return 1; else return 2; }
	if (mayor1 == false && mayor2 == false) { if (vps >= vn) return 1; else return 3; }

}