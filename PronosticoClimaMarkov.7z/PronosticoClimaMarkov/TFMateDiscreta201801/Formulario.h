#pragma once
#include "ControladorValores.h"
#include "Controlador.h"
#include<msclr/marshal_cppstd.h>
#include <ctime>
#include <string>  

using namespace System;

namespace TFMateDiscreta201801 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Formulario
	/// </summary>
	public ref class Formulario : public System::Windows::Forms::Form
	{
	public:
		Formulario(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			controlador = new CControlador();

			bmpInicio = gcnew Bitmap("weather3.jpg");
			bmpAte = gcnew Bitmap("ate.jpg");
			bmpChaclacayo = gcnew Bitmap("chaclacayo.jpg");
			bmpLa_Molina = gcnew Bitmap("lamolina.jpg");
			bmpSan_Isidro = gcnew Bitmap("sanisidro.jpg");
			bmpSantiago_de_Surco = gcnew Bitmap("surco.jpg");

			soleado = gcnew Bitmap("soleado.jpg");
			psoleado = gcnew Bitmap("psoleado.jpg");
			pnublado = gcnew Bitmap("pnublado.jpg");
			nublado = gcnew Bitmap("nublado.jpg");

			g = this->CreateGraphics();
		}	

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Formulario()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		CControlador* controlador;
		Graphics^ g;
		BufferedGraphicsContext^ bgc;
		BufferedGraphics^ bg;

		Bitmap^ bmpInicio;
		Bitmap^ bmpAte;
		Bitmap^ bmpChaclacayo;
		Bitmap^ bmpLa_Molina;
		Bitmap^ bmpSan_Isidro;
		Bitmap^ bmpSantiago_de_Surco;

		Bitmap^ soleado;
		Bitmap^ psoleado;
		Bitmap^ pnublado;
		Bitmap^ nublado;

	protected:
	private: System::Windows::Forms::Button^  btnAleatorios;
	private: System::Windows::Forms::TextBox^  txbDiasAleatorios;
	private: System::Windows::Forms::Label^  label1;


	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txbnRn;
	private: System::Windows::Forms::TextBox^  txbnRpn;
	private: System::Windows::Forms::TextBox^  txbnRps;
	private: System::Windows::Forms::TextBox^  txbnRs;
	private: System::Windows::Forms::TextBox^  txbpnRn;
	private: System::Windows::Forms::TextBox^  txbpnRpn;
	private: System::Windows::Forms::TextBox^  txbpnRps;
	private: System::Windows::Forms::TextBox^  txbpnRs;
	private: System::Windows::Forms::TextBox^  txbpsRn;
	private: System::Windows::Forms::TextBox^  txbpsRpn;
	private: System::Windows::Forms::TextBox^  txbpsRps;
	private: System::Windows::Forms::TextBox^  txbpsRs;
	private: System::Windows::Forms::TextBox^  txbsRn;
	private: System::Windows::Forms::TextBox^  txbsRpn;
	private: System::Windows::Forms::TextBox^  txbsRps;
	private: System::Windows::Forms::TextBox^  txbsRs;



	private: System::Windows::Forms::Button^  btnReales;
	private: System::Windows::Forms::ComboBox^  cbbDistritos;


	private: System::Windows::Forms::Label^  label10;

	private: System::Windows::Forms::RichTextBox^  rtbArreglo;
	private: System::Windows::Forms::Timer^  timer1;
	private: System::Windows::Forms::Label^  label11;

	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::Label^  label18;
	private: System::Windows::Forms::Label^  label19;

	private: System::Windows::Forms::PictureBox^  pbUltimoDia;
	private: System::Windows::Forms::RichTextBox^  rtbUltimoDia;
	private: System::Windows::Forms::RichTextBox^  rtbDiaSig1;
	private: System::Windows::Forms::RichTextBox^  rtbDiaSig2;
	private: System::Windows::Forms::RichTextBox^  rtbDiaSig3;
	private: System::Windows::Forms::RichTextBox^  rtbDiaSig4;
	private: System::Windows::Forms::RichTextBox^  rtbDiaSig5;
private: System::Windows::Forms::PictureBox^  pbDiaSig1;
private: System::Windows::Forms::PictureBox^  pbDiaSig2;
private: System::Windows::Forms::PictureBox^  pbDiaSig3;
private: System::Windows::Forms::PictureBox^  pbDiaSig4;
private: System::Windows::Forms::PictureBox^  pbDiaSig5;










	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->btnAleatorios = (gcnew System::Windows::Forms::Button());
			this->txbDiasAleatorios = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnReales = (gcnew System::Windows::Forms::Button());
			this->cbbDistritos = (gcnew System::Windows::Forms::ComboBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txbnRn = (gcnew System::Windows::Forms::TextBox());
			this->txbnRpn = (gcnew System::Windows::Forms::TextBox());
			this->txbnRps = (gcnew System::Windows::Forms::TextBox());
			this->txbnRs = (gcnew System::Windows::Forms::TextBox());
			this->txbpnRn = (gcnew System::Windows::Forms::TextBox());
			this->txbpnRpn = (gcnew System::Windows::Forms::TextBox());
			this->txbpnRps = (gcnew System::Windows::Forms::TextBox());
			this->txbpnRs = (gcnew System::Windows::Forms::TextBox());
			this->txbpsRn = (gcnew System::Windows::Forms::TextBox());
			this->txbpsRpn = (gcnew System::Windows::Forms::TextBox());
			this->txbpsRps = (gcnew System::Windows::Forms::TextBox());
			this->txbpsRs = (gcnew System::Windows::Forms::TextBox());
			this->txbsRn = (gcnew System::Windows::Forms::TextBox());
			this->txbsRpn = (gcnew System::Windows::Forms::TextBox());
			this->txbsRps = (gcnew System::Windows::Forms::TextBox());
			this->txbsRs = (gcnew System::Windows::Forms::TextBox());
			this->rtbArreglo = (gcnew System::Windows::Forms::RichTextBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->pbUltimoDia = (gcnew System::Windows::Forms::PictureBox());
			this->rtbUltimoDia = (gcnew System::Windows::Forms::RichTextBox());
			this->rtbDiaSig1 = (gcnew System::Windows::Forms::RichTextBox());
			this->rtbDiaSig2 = (gcnew System::Windows::Forms::RichTextBox());
			this->rtbDiaSig3 = (gcnew System::Windows::Forms::RichTextBox());
			this->rtbDiaSig4 = (gcnew System::Windows::Forms::RichTextBox());
			this->rtbDiaSig5 = (gcnew System::Windows::Forms::RichTextBox());
			this->pbDiaSig1 = (gcnew System::Windows::Forms::PictureBox());
			this->pbDiaSig2 = (gcnew System::Windows::Forms::PictureBox());
			this->pbDiaSig3 = (gcnew System::Windows::Forms::PictureBox());
			this->pbDiaSig4 = (gcnew System::Windows::Forms::PictureBox());
			this->pbDiaSig5 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbUltimoDia))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig5))->BeginInit();
			this->SuspendLayout();
			// 
			// btnAleatorios
			// 
			this->btnAleatorios->Location = System::Drawing::Point(194, 9);
			this->btnAleatorios->Margin = System::Windows::Forms::Padding(2);
			this->btnAleatorios->Name = L"btnAleatorios";
			this->btnAleatorios->Size = System::Drawing::Size(90, 19);
			this->btnAleatorios->TabIndex = 2;
			this->btnAleatorios->Text = L"Generar Dias";
			this->btnAleatorios->UseVisualStyleBackColor = true;
			this->btnAleatorios->Click += gcnew System::EventHandler(this, &Formulario::btnAleatorios_Click);
			// 
			// txbDiasAleatorios
			// 
			this->txbDiasAleatorios->Location = System::Drawing::Point(115, 10);
			this->txbDiasAleatorios->Margin = System::Windows::Forms::Padding(2);
			this->txbDiasAleatorios->Name = L"txbDiasAleatorios";
			this->txbDiasAleatorios->Size = System::Drawing::Size(76, 20);
			this->txbDiasAleatorios->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(9, 12);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(88, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Numero de D�as:";
			// 
			// btnReales
			// 
			this->btnReales->Location = System::Drawing::Point(194, 48);
			this->btnReales->Margin = System::Windows::Forms::Padding(2);
			this->btnReales->Name = L"btnReales";
			this->btnReales->Size = System::Drawing::Size(90, 19);
			this->btnReales->TabIndex = 2;
			this->btnReales->Text = L"Obtener Dias";
			this->btnReales->UseVisualStyleBackColor = true;
			this->btnReales->Click += gcnew System::EventHandler(this, &Formulario::btnReales_Click);
			// 
			// cbbDistritos
			// 
			this->cbbDistritos->FormattingEnabled = true;
			this->cbbDistritos->Items->AddRange(gcnew cli::array< System::Object^  >(5) {
				L"Ate", L"Chaclacayo", L"La Molina", L"San Isidro",
					L"Santiago de Surco"
			});
			this->cbbDistritos->Location = System::Drawing::Point(99, 47);
			this->cbbDistritos->Margin = System::Windows::Forms::Padding(2);
			this->cbbDistritos->Name = L"cbbDistritos";
			this->cbbDistritos->Size = System::Drawing::Size(92, 21);
			this->cbbDistritos->TabIndex = 1;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(10, 49);
			this->label10->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(84, 13);
			this->label10->TabIndex = 0;
			this->label10->Text = L"Escoger Distrito:";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(651, 33);
			this->label9->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(45, 13);
			this->label9->TabIndex = 23;
			this->label9->Text = L"nublado";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(569, 33);
			this->label8->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(54, 13);
			this->label8->TabIndex = 22;
			this->label8->Text = L"p.nublado";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(487, 33);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(56, 13);
			this->label7->TabIndex = 21;
			this->label7->Text = L"p. soleado";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(413, 33);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(44, 13);
			this->label6->TabIndex = 20;
			this->label6->Text = L"soleado";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(347, 125);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(45, 13);
			this->label5->TabIndex = 19;
			this->label5->Text = L"nublado";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(335, 102);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(57, 13);
			this->label4->TabIndex = 18;
			this->label4->Text = L"p. nublado";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(336, 78);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(56, 13);
			this->label3->TabIndex = 17;
			this->label3->Text = L"p. soleado";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(348, 55);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 16;
			this->label2->Text = L"soleado";
			// 
			// txbnRn
			// 
			this->txbnRn->Location = System::Drawing::Point(636, 123);
			this->txbnRn->Margin = System::Windows::Forms::Padding(2);
			this->txbnRn->Name = L"txbnRn";
			this->txbnRn->ReadOnly = true;
			this->txbnRn->Size = System::Drawing::Size(76, 20);
			this->txbnRn->TabIndex = 15;
			// 
			// txbnRpn
			// 
			this->txbnRpn->Location = System::Drawing::Point(556, 123);
			this->txbnRpn->Margin = System::Windows::Forms::Padding(2);
			this->txbnRpn->Name = L"txbnRpn";
			this->txbnRpn->ReadOnly = true;
			this->txbnRpn->Size = System::Drawing::Size(76, 20);
			this->txbnRpn->TabIndex = 14;
			// 
			// txbnRps
			// 
			this->txbnRps->Location = System::Drawing::Point(476, 123);
			this->txbnRps->Margin = System::Windows::Forms::Padding(2);
			this->txbnRps->Name = L"txbnRps";
			this->txbnRps->ReadOnly = true;
			this->txbnRps->Size = System::Drawing::Size(76, 20);
			this->txbnRps->TabIndex = 13;
			// 
			// txbnRs
			// 
			this->txbnRs->Location = System::Drawing::Point(396, 124);
			this->txbnRs->Margin = System::Windows::Forms::Padding(2);
			this->txbnRs->Name = L"txbnRs";
			this->txbnRs->ReadOnly = true;
			this->txbnRs->Size = System::Drawing::Size(76, 20);
			this->txbnRs->TabIndex = 12;
			// 
			// txbpnRn
			// 
			this->txbpnRn->Location = System::Drawing::Point(636, 99);
			this->txbpnRn->Margin = System::Windows::Forms::Padding(2);
			this->txbpnRn->Name = L"txbpnRn";
			this->txbpnRn->ReadOnly = true;
			this->txbpnRn->Size = System::Drawing::Size(76, 20);
			this->txbpnRn->TabIndex = 11;
			// 
			// txbpnRpn
			// 
			this->txbpnRpn->Location = System::Drawing::Point(556, 99);
			this->txbpnRpn->Margin = System::Windows::Forms::Padding(2);
			this->txbpnRpn->Name = L"txbpnRpn";
			this->txbpnRpn->ReadOnly = true;
			this->txbpnRpn->Size = System::Drawing::Size(76, 20);
			this->txbpnRpn->TabIndex = 10;
			// 
			// txbpnRps
			// 
			this->txbpnRps->Location = System::Drawing::Point(476, 99);
			this->txbpnRps->Margin = System::Windows::Forms::Padding(2);
			this->txbpnRps->Name = L"txbpnRps";
			this->txbpnRps->ReadOnly = true;
			this->txbpnRps->Size = System::Drawing::Size(76, 20);
			this->txbpnRps->TabIndex = 9;
			// 
			// txbpnRs
			// 
			this->txbpnRs->Location = System::Drawing::Point(396, 100);
			this->txbpnRs->Margin = System::Windows::Forms::Padding(2);
			this->txbpnRs->Name = L"txbpnRs";
			this->txbpnRs->ReadOnly = true;
			this->txbpnRs->Size = System::Drawing::Size(76, 20);
			this->txbpnRs->TabIndex = 8;
			// 
			// txbpsRn
			// 
			this->txbpsRn->Location = System::Drawing::Point(636, 76);
			this->txbpsRn->Margin = System::Windows::Forms::Padding(2);
			this->txbpsRn->Name = L"txbpsRn";
			this->txbpsRn->ReadOnly = true;
			this->txbpsRn->Size = System::Drawing::Size(76, 20);
			this->txbpsRn->TabIndex = 7;
			// 
			// txbpsRpn
			// 
			this->txbpsRpn->Location = System::Drawing::Point(556, 77);
			this->txbpsRpn->Margin = System::Windows::Forms::Padding(2);
			this->txbpsRpn->Name = L"txbpsRpn";
			this->txbpsRpn->ReadOnly = true;
			this->txbpsRpn->Size = System::Drawing::Size(76, 20);
			this->txbpsRpn->TabIndex = 6;
			// 
			// txbpsRps
			// 
			this->txbpsRps->Location = System::Drawing::Point(476, 76);
			this->txbpsRps->Margin = System::Windows::Forms::Padding(2);
			this->txbpsRps->Name = L"txbpsRps";
			this->txbpsRps->ReadOnly = true;
			this->txbpsRps->Size = System::Drawing::Size(76, 20);
			this->txbpsRps->TabIndex = 5;
			// 
			// txbpsRs
			// 
			this->txbpsRs->Location = System::Drawing::Point(396, 77);
			this->txbpsRs->Margin = System::Windows::Forms::Padding(2);
			this->txbpsRs->Name = L"txbpsRs";
			this->txbpsRs->ReadOnly = true;
			this->txbpsRs->Size = System::Drawing::Size(76, 20);
			this->txbpsRs->TabIndex = 4;
			// 
			// txbsRn
			// 
			this->txbsRn->Location = System::Drawing::Point(636, 53);
			this->txbsRn->Margin = System::Windows::Forms::Padding(2);
			this->txbsRn->Name = L"txbsRn";
			this->txbsRn->ReadOnly = true;
			this->txbsRn->Size = System::Drawing::Size(76, 20);
			this->txbsRn->TabIndex = 3;
			// 
			// txbsRpn
			// 
			this->txbsRpn->Location = System::Drawing::Point(556, 52);
			this->txbsRpn->Margin = System::Windows::Forms::Padding(2);
			this->txbsRpn->Name = L"txbsRpn";
			this->txbsRpn->ReadOnly = true;
			this->txbsRpn->Size = System::Drawing::Size(76, 20);
			this->txbsRpn->TabIndex = 2;
			// 
			// txbsRps
			// 
			this->txbsRps->Location = System::Drawing::Point(476, 52);
			this->txbsRps->Margin = System::Windows::Forms::Padding(2);
			this->txbsRps->Name = L"txbsRps";
			this->txbsRps->ReadOnly = true;
			this->txbsRps->Size = System::Drawing::Size(76, 20);
			this->txbsRps->TabIndex = 1;
			// 
			// txbsRs
			// 
			this->txbsRs->Location = System::Drawing::Point(396, 53);
			this->txbsRs->Margin = System::Windows::Forms::Padding(2);
			this->txbsRs->Name = L"txbsRs";
			this->txbsRs->ReadOnly = true;
			this->txbsRs->Size = System::Drawing::Size(76, 20);
			this->txbsRs->TabIndex = 0;
			// 
			// rtbArreglo
			// 
			this->rtbArreglo->Location = System::Drawing::Point(9, 120);
			this->rtbArreglo->Margin = System::Windows::Forms::Padding(2);
			this->rtbArreglo->Name = L"rtbArreglo";
			this->rtbArreglo->Size = System::Drawing::Size(146, 362);
			this->rtbArreglo->TabIndex = 0;
			this->rtbArreglo->Text = L"";
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &Formulario::timer1_Tick);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(41, 102);
			this->label11->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(88, 13);
			this->label11->TabIndex = 24;
			this->label11->Text = L"Arreglo de Climas";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(531, 10);
			this->label13->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(35, 13);
			this->label13->TabIndex = 26;
			this->label13->Text = L"Matriz";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(208, 159);
			this->label14->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(60, 13);
			this->label14->TabIndex = 27;
			this->label14->Text = L"�ltimo D�a:";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(322, 159);
			this->label15->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(55, 13);
			this->label15->TabIndex = 28;
			this->label15->Text = L"D�a Sig 1:";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(439, 159);
			this->label16->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(55, 13);
			this->label16->TabIndex = 29;
			this->label16->Text = L"D�a Sig 2:";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(528, 159);
			this->label17->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(55, 13);
			this->label17->TabIndex = 30;
			this->label17->Text = L"D�a Sig 3:";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(638, 159);
			this->label18->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(55, 13);
			this->label18->TabIndex = 31;
			this->label18->Text = L"D�a Sig 4:";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(750, 159);
			this->label19->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(55, 13);
			this->label19->TabIndex = 32;
			this->label19->Text = L"D�a Sig 5:";
			// 
			// pbUltimoDia
			// 
			this->pbUltimoDia->Location = System::Drawing::Point(187, 313);
			this->pbUltimoDia->Margin = System::Windows::Forms::Padding(2);
			this->pbUltimoDia->Name = L"pbUltimoDia";
			this->pbUltimoDia->Size = System::Drawing::Size(102, 93);
			this->pbUltimoDia->TabIndex = 34;
			this->pbUltimoDia->TabStop = false;
			// 
			// rtbUltimoDia
			// 
			this->rtbUltimoDia->Location = System::Drawing::Point(187, 178);
			this->rtbUltimoDia->Margin = System::Windows::Forms::Padding(2);
			this->rtbUltimoDia->Name = L"rtbUltimoDia";
			this->rtbUltimoDia->Size = System::Drawing::Size(103, 132);
			this->rtbUltimoDia->TabIndex = 35;
			this->rtbUltimoDia->Text = L"";
			// 
			// rtbDiaSig1
			// 
			this->rtbDiaSig1->Location = System::Drawing::Point(294, 178);
			this->rtbDiaSig1->Margin = System::Windows::Forms::Padding(2);
			this->rtbDiaSig1->Name = L"rtbDiaSig1";
			this->rtbDiaSig1->Size = System::Drawing::Size(103, 132);
			this->rtbDiaSig1->TabIndex = 36;
			this->rtbDiaSig1->Text = L"";
			// 
			// rtbDiaSig2
			// 
			this->rtbDiaSig2->Location = System::Drawing::Point(400, 178);
			this->rtbDiaSig2->Margin = System::Windows::Forms::Padding(2);
			this->rtbDiaSig2->Name = L"rtbDiaSig2";
			this->rtbDiaSig2->Size = System::Drawing::Size(103, 132);
			this->rtbDiaSig2->TabIndex = 37;
			this->rtbDiaSig2->Text = L"";
			// 
			// rtbDiaSig3
			// 
			this->rtbDiaSig3->Location = System::Drawing::Point(506, 178);
			this->rtbDiaSig3->Margin = System::Windows::Forms::Padding(2);
			this->rtbDiaSig3->Name = L"rtbDiaSig3";
			this->rtbDiaSig3->Size = System::Drawing::Size(103, 132);
			this->rtbDiaSig3->TabIndex = 38;
			this->rtbDiaSig3->Text = L"";
			// 
			// rtbDiaSig4
			// 
			this->rtbDiaSig4->Location = System::Drawing::Point(613, 178);
			this->rtbDiaSig4->Margin = System::Windows::Forms::Padding(2);
			this->rtbDiaSig4->Name = L"rtbDiaSig4";
			this->rtbDiaSig4->Size = System::Drawing::Size(103, 132);
			this->rtbDiaSig4->TabIndex = 39;
			this->rtbDiaSig4->Text = L"";
			// 
			// rtbDiaSig5
			// 
			this->rtbDiaSig5->Location = System::Drawing::Point(720, 178);
			this->rtbDiaSig5->Margin = System::Windows::Forms::Padding(2);
			this->rtbDiaSig5->Name = L"rtbDiaSig5";
			this->rtbDiaSig5->Size = System::Drawing::Size(103, 132);
			this->rtbDiaSig5->TabIndex = 40;
			this->rtbDiaSig5->Text = L"";
			// 
			// pbDiaSig1
			// 
			this->pbDiaSig1->Location = System::Drawing::Point(294, 313);
			this->pbDiaSig1->Margin = System::Windows::Forms::Padding(2);
			this->pbDiaSig1->Name = L"pbDiaSig1";
			this->pbDiaSig1->Size = System::Drawing::Size(102, 93);
			this->pbDiaSig1->TabIndex = 41;
			this->pbDiaSig1->TabStop = false;
			// 
			// pbDiaSig2
			// 
			this->pbDiaSig2->Location = System::Drawing::Point(400, 313);
			this->pbDiaSig2->Margin = System::Windows::Forms::Padding(2);
			this->pbDiaSig2->Name = L"pbDiaSig2";
			this->pbDiaSig2->Size = System::Drawing::Size(102, 93);
			this->pbDiaSig2->TabIndex = 42;
			this->pbDiaSig2->TabStop = false;
			// 
			// pbDiaSig3
			// 
			this->pbDiaSig3->Location = System::Drawing::Point(506, 313);
			this->pbDiaSig3->Margin = System::Windows::Forms::Padding(2);
			this->pbDiaSig3->Name = L"pbDiaSig3";
			this->pbDiaSig3->Size = System::Drawing::Size(102, 93);
			this->pbDiaSig3->TabIndex = 43;
			this->pbDiaSig3->TabStop = false;
			// 
			// pbDiaSig4
			// 
			this->pbDiaSig4->Location = System::Drawing::Point(613, 313);
			this->pbDiaSig4->Margin = System::Windows::Forms::Padding(2);
			this->pbDiaSig4->Name = L"pbDiaSig4";
			this->pbDiaSig4->Size = System::Drawing::Size(102, 93);
			this->pbDiaSig4->TabIndex = 44;
			this->pbDiaSig4->TabStop = false;
			// 
			// pbDiaSig5
			// 
			this->pbDiaSig5->Location = System::Drawing::Point(720, 313);
			this->pbDiaSig5->Margin = System::Windows::Forms::Padding(2);
			this->pbDiaSig5->Name = L"pbDiaSig5";
			this->pbDiaSig5->Size = System::Drawing::Size(102, 93);
			this->pbDiaSig5->TabIndex = 45;
			this->pbDiaSig5->TabStop = false;
			// 
			// Formulario
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(865, 491);
			this->Controls->Add(this->pbDiaSig5);
			this->Controls->Add(this->pbDiaSig4);
			this->Controls->Add(this->pbDiaSig3);
			this->Controls->Add(this->pbDiaSig2);
			this->Controls->Add(this->pbDiaSig1);
			this->Controls->Add(this->rtbDiaSig5);
			this->Controls->Add(this->rtbDiaSig4);
			this->Controls->Add(this->rtbDiaSig3);
			this->Controls->Add(this->rtbDiaSig2);
			this->Controls->Add(this->rtbDiaSig1);
			this->Controls->Add(this->rtbUltimoDia);
			this->Controls->Add(this->pbUltimoDia);
			this->Controls->Add(this->label19);
			this->Controls->Add(this->label18);
			this->Controls->Add(this->label17);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->rtbArreglo);
			this->Controls->Add(this->btnAleatorios);
			this->Controls->Add(this->btnReales);
			this->Controls->Add(this->txbDiasAleatorios);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->cbbDistritos);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txbpsRs);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txbsRs);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txbsRps);
			this->Controls->Add(this->txbnRn);
			this->Controls->Add(this->txbsRpn);
			this->Controls->Add(this->txbnRpn);
			this->Controls->Add(this->txbsRn);
			this->Controls->Add(this->txbnRps);
			this->Controls->Add(this->txbpsRps);
			this->Controls->Add(this->txbnRs);
			this->Controls->Add(this->txbpsRpn);
			this->Controls->Add(this->txbpnRn);
			this->Controls->Add(this->txbpsRn);
			this->Controls->Add(this->txbpnRpn);
			this->Controls->Add(this->txbpnRs);
			this->Controls->Add(this->txbpnRps);
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Formulario";
			this->Text = L"Climas UPC";
			this->Load += gcnew System::EventHandler(this, &Formulario::Formulario_Load);
			this->BackgroundImageChanged += gcnew System::EventHandler(this, &Formulario::btnReales_Click);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbUltimoDia))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pbDiaSig5))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void btnAleatorios_Click(System::Object^  sender, System::EventArgs^  e) {
		timer1->Enabled = true;
		//CONVERTIR LOS DIAS INGRESADOS DE STRING A INT
		controlador->getCV()->obtenerValoresAleatorios(Convert::ToInt16(txbDiasAleatorios->Text));

		//GENERAR CADA UNO DE LOS 16 VALORES Y LAS SUMAS DE CADA DIA
		controlador->getCV()->generarMatriz();

		///////////////////////////PROCESO PARA IMPRIMIR LOS DIAS

		rtbArreglo->SelectionBullet = true;

		int* arrdias = controlador->getCV()->getarrdias();
		for (int i = 0; i < controlador->getCV()->getdias(); i++) {

			rtbArreglo->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
			rtbArreglo->SelectionColor = Color::Black;

			if (arrdias[i] == 0) rtbArreglo->SelectedText = "Soleado";
			if (arrdias[i] == 1) rtbArreglo->SelectedText = "Par. Soleado";
			if (arrdias[i] == 2) rtbArreglo->SelectedText = "Par. Nublado";
			if (arrdias[i] == 3) rtbArreglo->SelectedText = "Nublado";
			
			rtbArreglo->SelectedText = "\n";

		}

		rtbArreglo->SelectionBullet = false;

		/////////////////////////// PROCESO PARA IMPRIMIR LA MATRIZ
		//DATOS  DE CADA POSIBILIDAD
		{
			txbsRs->Text = Convert::ToString(controlador->getCV()->getsRs());
			txbsRps->Text = Convert::ToString(controlador->getCV()->getsRps());
			txbsRpn->Text = Convert::ToString(controlador->getCV()->getsRpn());
			txbsRn->Text = Convert::ToString(controlador->getCV()->getsRn());

			txbpsRs->Text = Convert::ToString(controlador->getCV()->getpsRs());
			txbpsRps->Text = Convert::ToString(controlador->getCV()->getpsRps());
			txbpsRpn->Text = Convert::ToString(controlador->getCV()->getpsRpn());
			txbpsRn->Text = Convert::ToString(controlador->getCV()->getpsRn());

			txbpnRs->Text = Convert::ToString(controlador->getCV()->getpnRs());
			txbpnRps->Text = Convert::ToString(controlador->getCV()->getpnRps());
			txbpnRpn->Text = Convert::ToString(controlador->getCV()->getpnRpn());
			txbpnRn->Text = Convert::ToString(controlador->getCV()->getpnRn());

			txbnRs->Text = Convert::ToString(controlador->getCV()->getnRs());
			txbnRps->Text = Convert::ToString(controlador->getCV()->getnRps());
			txbnRpn->Text = Convert::ToString(controlador->getCV()->getnRpn());
			txbnRn->Text = Convert::ToString(controlador->getCV()->getnRn());
		}


		//////////////////////////PROCESO PARA INGRESAR DIAS SIGUIENTES A LOS PICTURE BOX
		int ultdia;

		rtbUltimoDia->Clear();
		rtbUltimoDia->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbUltimoDia->SelectionColor = Color::Black;
		rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbUltimoDia->SelectedText = "; ";
		rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbUltimoDia->SelectedText = "; ";
		rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbUltimoDia->SelectedText = "; ";
		rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		ultdia = controlador->getCV()->getvector()->calMayor();
		rtbUltimoDia->SelectedText = "; ";
		if (ultdia == 0) { pbUltimoDia->Image = soleado; rtbUltimoDia->SelectedText = " Soleado"; }
		if (ultdia == 1) { pbUltimoDia->Image = psoleado; rtbUltimoDia->SelectedText = " Par.Soleado"; }
		if (ultdia == 2) { pbUltimoDia->Image = pnublado; rtbUltimoDia->SelectedText = " Par.Nublado";	}
		if (ultdia == 3){ pbUltimoDia->Image = nublado; rtbUltimoDia->SelectedText = " Nublado"; }

		int diasig1;
		controlador->getCV()->calSigVector();
		rtbDiaSig1->Clear();
		rtbDiaSig1->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbDiaSig1->SelectionColor = Color::Black;
		rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbDiaSig1->SelectedText = "; ";
		rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbDiaSig1->SelectedText = "; ";
		rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbDiaSig1->SelectedText = "; ";
		rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		diasig1 = controlador->getCV()->getvector()->calMayor();
		rtbDiaSig1->SelectedText = "; ";
		if (diasig1 == 0) { pbDiaSig1->Image = soleado; rtbDiaSig1->SelectedText = " Soleado"; }
		if (diasig1 == 1) { pbDiaSig1->Image = psoleado; rtbDiaSig1->SelectedText = " Par.Soleado"; }
		if (diasig1 == 2) { pbDiaSig1->Image = pnublado; rtbDiaSig1->SelectedText = " Par.Nublado"; }
		if (diasig1 == 3) { pbDiaSig1->Image = nublado; rtbDiaSig1->SelectedText = " Nublado"; }

		int diasig2;
		controlador->getCV()->calSigVector();
		rtbDiaSig2->Clear();
		rtbDiaSig2->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbDiaSig2->SelectionColor = Color::Black;
		rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbDiaSig2->SelectedText = "; ";
		rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbDiaSig2->SelectedText = "; ";
		rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbDiaSig2->SelectedText = "; ";
		rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		diasig2 = controlador->getCV()->getvector()->calMayor();
		rtbDiaSig2->SelectedText = "; ";
		if (diasig2 == 0) { pbDiaSig2->Image = soleado; rtbDiaSig2->SelectedText = " Soleado"; }
		if (diasig2 == 1) { pbDiaSig2->Image = psoleado; rtbDiaSig2->SelectedText = " Par.Soleado"; }
		if (diasig2 == 2) { pbDiaSig2->Image = pnublado; rtbDiaSig2->SelectedText = " Par.Nublado"; }
		if (diasig2 == 3) { pbDiaSig2->Image = nublado; rtbDiaSig2->SelectedText = " Nublado"; }

		int diasig3;
		controlador->getCV()->calSigVector();
		rtbDiaSig3->Clear();
		rtbDiaSig3->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbDiaSig3->SelectionColor = Color::Black;
		rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbDiaSig3->SelectedText = "; ";
		rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbDiaSig3->SelectedText = "; ";
		rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbDiaSig3->SelectedText = "; ";
		rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		diasig3 = controlador->getCV()->getvector()->calMayor();
		rtbDiaSig3->SelectedText = "; ";
		if (diasig3 == 0) { pbDiaSig3->Image = soleado; rtbDiaSig3->SelectedText = " Soleado"; }
		if (diasig3 == 1) { pbDiaSig3->Image = psoleado; rtbDiaSig3->SelectedText = " Par.Soleado"; }
		if (diasig3 == 2) { pbDiaSig3->Image = pnublado; rtbDiaSig3->SelectedText = " Par.Nublado"; }
		if (diasig3 == 3) { pbDiaSig3->Image = nublado; rtbDiaSig3->SelectedText = " Nublado"; }

		int diasig4;
		controlador->getCV()->calSigVector();
		rtbDiaSig4->Clear();
		rtbDiaSig4->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbDiaSig4->SelectionColor = Color::Black;
		rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbDiaSig4->SelectedText = "; ";
		rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbDiaSig4->SelectedText = "; ";
		rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbDiaSig4->SelectedText = "; ";
		rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		diasig4 = controlador->getCV()->getvector()->calMayor();
		rtbDiaSig4->SelectedText = "; ";
		if (diasig4 == 0) { pbDiaSig4->Image = soleado; rtbDiaSig4->SelectedText = " Soleado"; }
		if (diasig4 == 1) { pbDiaSig4->Image = psoleado; rtbDiaSig4->SelectedText = " Par.Soleado"; }
		if (diasig4 == 2) { pbDiaSig4->Image = pnublado; rtbDiaSig4->SelectedText = " Par.Nublado"; }
		if (diasig4 == 3) { pbDiaSig4->Image = nublado; rtbDiaSig4->SelectedText = " Nublado"; }

		int diasig5;
		controlador->getCV()->calSigVector();
		rtbDiaSig5->Clear();
		rtbDiaSig5->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbDiaSig5->SelectionColor = Color::Black;
		rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
		rtbDiaSig5->SelectedText = "; ";
		rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
		rtbDiaSig5->SelectedText = "; ";
		rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
		rtbDiaSig5->SelectedText = "; ";
		rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
		diasig5 = controlador->getCV()->getvector()->calMayor();
		rtbDiaSig5->SelectedText = "; ";
		if (diasig5 == 0) { pbDiaSig5->Image = soleado; rtbDiaSig5->SelectedText = " Soleado"; }
		if (diasig5 == 1) { pbDiaSig5->Image = psoleado; rtbDiaSig5->SelectedText = " Par.Soleado"; }
		if (diasig5 == 2) { pbDiaSig5->Image = pnublado; rtbDiaSig5->SelectedText = " Par.Nublado"; }
		if (diasig5 == 3) { pbDiaSig5->Image = nublado; rtbDiaSig5->SelectedText = " Nublado"; }


		//resetear
		controlador->reiniciarCV();
	}
private: System::Void btnReales_Click(System::Object^  sender, System::EventArgs^  e) {

	timer1->Enabled = false;
	g->Clear(Color::White);
	//CONVERTIR LOS DIAS INGRESADOS DE STRING A INT
	String^ nomdistrito_String = cbbDistritos->Text;
	string nomdistrito_string = msclr::interop::marshal_as<string>(nomdistrito_String);

	//OBTENER DATOS DEL DISTRITO
	controlador->getCV()->obtenerValoresReales(nomdistrito_string);
	if (nomdistrito_string == "Ate") { bmpAte->MakeTransparent(bmpAte->GetPixel(1, 1)); g->DrawImage(bmpAte, 0, 0);  }
	if (nomdistrito_string == "La Molina") { bmpLa_Molina->MakeTransparent(bmpLa_Molina->GetPixel(1, 1)); g->DrawImage(bmpLa_Molina, 0, 0);  }
	if (nomdistrito_string == "San Isidro") { bmpSan_Isidro->MakeTransparent(bmpSan_Isidro->GetPixel(1, 1)); g->DrawImage(bmpSan_Isidro, 0, 0); }
	if (nomdistrito_string == "Santiago de Surco") { bmpSantiago_de_Surco->MakeTransparent(bmpSantiago_de_Surco->GetPixel(1, 1)); g->DrawImage(bmpSantiago_de_Surco, 0, 0); }
	if (nomdistrito_string == "Chaclacayo") { bmpChaclacayo->MakeTransparent(bmpChaclacayo->GetPixel(1, 1)); g->DrawImage(bmpChaclacayo, 0, 0); }

	//GENERAR MATRIZ
	controlador->getCV()->generarMatriz();

	///////////////////////////PROCESO PARA IMPRIMIR LOS DIAS

	rtbArreglo->SelectionBullet = true;

	int* arrdias = controlador->getCV()->getarrdias();
	for (int i = 0; i < controlador->getCV()->getdias(); i++) {

		rtbArreglo->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
		rtbArreglo->SelectionColor = Color::Black;

		if (arrdias[i] == 0) rtbArreglo->SelectedText = "Soleado";
		if (arrdias[i] == 1) rtbArreglo->SelectedText = "Par. Soleado";
		if (arrdias[i] == 2) rtbArreglo->SelectedText = "Par. Nublado";
		if (arrdias[i] == 3) rtbArreglo->SelectedText = "Nublado";

		rtbArreglo->SelectedText = "\n";

	}

	rtbArreglo->SelectionBullet = false;

	/////////////////////////// PROCESO PARA IMPRIMIR LA MATRIZ
	//DATOS  DE CADA POSIBILIDAD
	{
		txbsRs->Text = Convert::ToString(controlador->getCV()->getsRs());
		txbsRps->Text = Convert::ToString(controlador->getCV()->getsRps());
		txbsRpn->Text = Convert::ToString(controlador->getCV()->getsRpn());
		txbsRn->Text = Convert::ToString(controlador->getCV()->getsRn());

		txbpsRs->Text = Convert::ToString(controlador->getCV()->getpsRs());
		txbpsRps->Text = Convert::ToString(controlador->getCV()->getpsRps());
		txbpsRpn->Text = Convert::ToString(controlador->getCV()->getpsRpn());
		txbpsRn->Text = Convert::ToString(controlador->getCV()->getpsRn());

		txbpnRs->Text = Convert::ToString(controlador->getCV()->getpnRs());
		txbpnRps->Text = Convert::ToString(controlador->getCV()->getpnRps());
		txbpnRpn->Text = Convert::ToString(controlador->getCV()->getpnRpn());
		txbpnRn->Text = Convert::ToString(controlador->getCV()->getpnRn());

		txbnRs->Text = Convert::ToString(controlador->getCV()->getnRs());
		txbnRps->Text = Convert::ToString(controlador->getCV()->getnRps());
		txbnRpn->Text = Convert::ToString(controlador->getCV()->getnRpn());
		txbnRn->Text = Convert::ToString(controlador->getCV()->getnRn());
	}

	//////////////////////////PROCESO PARA INGRESAR DIAS SIGUIENTES A LOS PICTURE BOX
	int diasig;

	rtbUltimoDia->Clear();
	rtbUltimoDia->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbUltimoDia->SelectionColor = Color::Black;
	rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbUltimoDia->SelectedText = "; ";
	rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbUltimoDia->SelectedText = "; ";
	rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbUltimoDia->SelectedText = "; ";
	rtbUltimoDia->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbUltimoDia->SelectedText = "; ";
	if (diasig == 0) { pbUltimoDia->Image = soleado; rtbUltimoDia->SelectedText = " Soleado"; }
	if (diasig == 1) { pbUltimoDia->Image = psoleado; rtbUltimoDia->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbUltimoDia->Image = pnublado; rtbUltimoDia->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbUltimoDia->Image = nublado; rtbUltimoDia->SelectedText = " Nublado"; }

	controlador->getCV()->calSigVector();
	rtbDiaSig1->Clear();
	rtbDiaSig1->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbDiaSig1->SelectionColor = Color::Black;
	rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbDiaSig1->SelectedText = "; ";
	rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbDiaSig1->SelectedText = "; ";
	rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbDiaSig1->SelectedText = "; ";
	rtbDiaSig1->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbDiaSig1->SelectedText = "; ";
	if (diasig == 0) { pbDiaSig1->Image = soleado; rtbDiaSig1->SelectedText = " Soleado"; }
	if (diasig == 1) { pbDiaSig1->Image = psoleado; rtbDiaSig1->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbDiaSig1->Image = pnublado; rtbDiaSig1->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbDiaSig1->Image = nublado; rtbDiaSig1->SelectedText = " Nublado"; }

	controlador->getCV()->calSigVector();
	rtbDiaSig2->Clear();
	rtbDiaSig2->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbDiaSig2->SelectionColor = Color::Black;
	rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbDiaSig2->SelectedText = "; ";
	rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbDiaSig2->SelectedText = "; ";
	rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbDiaSig2->SelectedText = "; ";
	rtbDiaSig2->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbDiaSig2->SelectedText = "; ";
	if (diasig == 0) { pbDiaSig2->Image = soleado; rtbDiaSig2->SelectedText = " Soleado"; }
	if (diasig == 1) { pbDiaSig2->Image = psoleado; rtbDiaSig2->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbDiaSig2->Image = pnublado; rtbDiaSig2->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbDiaSig2->Image = nublado; rtbDiaSig2->SelectedText = " Nublado"; }

	controlador->getCV()->calSigVector();
	rtbDiaSig3->Clear();
	rtbDiaSig3->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbDiaSig3->SelectionColor = Color::Black;
	rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbDiaSig3->SelectedText = "; ";
	rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbDiaSig3->SelectedText = "; ";
	rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbDiaSig3->SelectedText = "; ";
	rtbDiaSig3->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbDiaSig3->SelectedText = "; ";
	if (diasig == 0) { pbDiaSig3->Image = soleado; rtbDiaSig3->SelectedText = " Soleado"; }
	if (diasig == 1) { pbDiaSig3->Image = psoleado; rtbDiaSig3->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbDiaSig3->Image = pnublado; rtbDiaSig3->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbDiaSig3->Image = nublado; rtbDiaSig3->SelectedText = " Nublado"; }

	controlador->getCV()->calSigVector();
	rtbDiaSig4->Clear();
	rtbDiaSig4->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbDiaSig4->SelectionColor = Color::Black;
	rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbDiaSig4->SelectedText = "; ";
	rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbDiaSig4->SelectedText = "; ";
	rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbDiaSig4->SelectedText = "; ";
	rtbDiaSig4->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbDiaSig4->SelectedText = "; ";
	if (diasig == 0) { pbDiaSig4->Image = soleado; rtbDiaSig4->SelectedText = " Soleado"; }
	if (diasig == 1) { pbDiaSig4->Image = psoleado; rtbDiaSig4->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbDiaSig4->Image = pnublado; rtbDiaSig4->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbDiaSig4->Image = nublado; rtbDiaSig4->SelectedText = " Nublado"; }

	controlador->getCV()->calSigVector();
	rtbDiaSig5->Clear();
	rtbDiaSig5->SelectionFont = gcnew System::Drawing::Font("Arial", 10);
	rtbDiaSig5->SelectionColor = Color::Black;
	rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvs());
	rtbDiaSig5->SelectedText = "; ";
	rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvps());
	rtbDiaSig5->SelectedText = "; ";
	rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvpn());
	rtbDiaSig5->SelectedText = "; ";
	rtbDiaSig5->SelectedText = Convert::ToString(controlador->getCV()->getvector()->getvn());
	diasig = controlador->getCV()->getvector()->calMayor();
	rtbDiaSig5->SelectedText = "; ";
	if (diasig == 0) { pbDiaSig5->Image = soleado; rtbDiaSig5->SelectedText = " Soleado"; }
	if (diasig == 1) { pbDiaSig5->Image = psoleado; rtbDiaSig5->SelectedText = " Par.Soleado"; }
	if (diasig == 2) { pbDiaSig5->Image = pnublado; rtbDiaSig5->SelectedText = " Par.Nublado"; }
	if (diasig == 3) { pbDiaSig5->Image = nublado; rtbDiaSig5->SelectedText = " Nublado"; }


	//resetear
	controlador->reiniciarCV();


}
private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
	bmpInicio->MakeTransparent(bmpInicio->GetPixel(1, 1));
	g->DrawImage(bmpInicio, 0, 0);
	
}
private: System::Void Formulario_Load(System::Object^  sender, System::EventArgs^  e) {
}
};
}
