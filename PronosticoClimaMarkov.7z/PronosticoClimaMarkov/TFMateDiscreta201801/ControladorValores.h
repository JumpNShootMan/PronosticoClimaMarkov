#pragma once
#include"Vector.h"
#include"ValoresDistritos.h"
#include <random>

using namespace std;

class CCV
{
public:
	CCV();
	~CCV();

	//METODOS GET Y SET

	CVector* getvector();

	int* getarrdias();
	int getdias();

	float getsRs();
	float getsRps();
	float getsRpn();
	float getsRn();

	float getpsRs();
	float getpsRps();
	float getpsRpn();
	float getpsRn();

	float getpnRs();
	float getpnRps();
	float getpnRpn();
	float getpnRn();

	float getnRs();
	float getnRps();
	float getnRpn();
	float getnRn();

	//METODOS DE LA LOGICA

	void obtenerValoresReales(string distrito);
	void obtenerValoresAleatorios(int numdias);
	void calSigVector();
	void generarMatriz();
	int getultimodia();

protected:
	CVector* vector;
	CVD* valores;

	int dias;
	int* arrdias;

	//en este se guarda los repetidos en la pasada actual
	int repetidos;

	//estos seran los atributos para ver repeticiones de dias siguentes. ej: 
	//soleadoREPnublado->(dias nublados que hubieron despues de un dia soleado)/(dias totales)

	float sRs;
	float sRps;
	float sRpn;
	float sRn;

	float psRs;
	float psRps;
	float psRpn;
	float psRn;

	float pnRs;
	float pnRps;
	float pnRpn;
	float pnRn;

	float nRs;
	float nRps;
	float nRpn;
	float nRn;
};

CCV::CCV()
{
	arrdias = new int[80];
	dias = 80;

	valores = new CVD();
	vector = new CVector();

	sRs = 0; sRps = 0; sRpn = 0; sRn = 0;

	psRs = 0; psRps = 0; psRpn = 0; psRn = 0;

	pnRs = 0; pnRps = 0; pnRpn = 0; pnRn = 0;

	nRs = 0; nRps = 0; nRpn = 0; nRn = 0;
}

CCV::~CCV()
{
}

//METODOS GET Y SET

CVector* CCV::getvector() { return vector; }

float CCV::getsRs() { return sRs; }
float CCV::getsRps() { return sRps; }
float CCV::getsRpn() { return sRpn; }
float CCV::getsRn() { return sRn; }

float CCV::getpsRs() { return psRs; }
float CCV::getpsRps() { return psRps; }
float CCV::getpsRpn() { return psRpn; }
float CCV::getpsRn() { return psRn; }

float CCV::getpnRs() { return pnRs; }
float CCV::getpnRps() { return pnRps; }
float CCV::getpnRpn() { return pnRpn; }
float CCV::getpnRn() { return pnRn; }

float CCV::getnRs() { return nRs; }
float CCV::getnRps() { return nRps; }
float CCV::getnRpn() { return nRpn; }
float CCV::getnRn() { return nRn; }

int* CCV::getarrdias() { return arrdias; }
int CCV::getdias() { return dias; }

//FUNCIONES DE LA LOGICA DEL PROGRAMA

void CCV::obtenerValoresReales(string distrito){

	if (distrito == "Ate") { arrdias = valores->getarrValAte(); }
	if (distrito == "Chaclacayo") { arrdias = valores->getarrValChaclacayo(); }
	if (distrito == "La Molina") { arrdias = valores->getarrValLa_Molina(); }
	if (distrito == "San Isidro") { arrdias = valores->getarrValSan_Isidro(); }
	if (distrito == "Santiago de Surco") { arrdias = valores->getarrValSantiago_de_Surco(); }

}
void CCV::obtenerValoresAleatorios(int numdias){
	dias = numdias;
	arrdias = new int[dias];

	for (int i = 0; i < dias; i++) {
		arrdias[i] = rand() % 4;
	}

}
void CCV::generarMatriz(){
	float sumaS = 0;
	float sumaPS = 0;
	float sumaPN = 0;
	float sumaN = 0;

	for (int h = 0; h < dias; h++) {
		if (arrdias[h] == 0) {
			if (arrdias[h + 1] == 0) sRs = sRs + 1;
			if (arrdias[h + 1] == 1) sRps = sRps + 1;
			if (arrdias[h + 1] == 2) sRpn = sRpn + 1;
			if (arrdias[h + 1] == 3) sRn = sRn + 1;
		}
		if (arrdias[h] == 1) {
			if (arrdias[h + 1] == 0) psRs = psRs + 1;
			if (arrdias[h + 1] == 1) psRps = psRps + 1;
			if (arrdias[h + 1] == 2) psRpn = psRpn + 1;
			if (arrdias[h + 1] == 3) psRn = psRn + 1;
		}
		if (arrdias[h] == 2) {
			if (arrdias[h + 1] == 0) pnRs = pnRs + 1;
			if (arrdias[h + 1] == 1) pnRps = pnRps + 1;
			if (arrdias[h + 1] == 2) pnRpn = pnRpn + 1;
			if (arrdias[h + 1] == 3) pnRn = pnRn + 1;
		}
		if (arrdias[h] == 3) {
			if (arrdias[h + 1] == 0) nRs = nRs + 1;
			if (arrdias[h + 1] == 1) nRps = nRps + 1;
			if (arrdias[h + 1] == 2) nRpn = nRpn + 1;
			if (arrdias[h + 1] == 3) nRn = nRn + 1;
		}
	}

	sumaS = sRs + sRps + sRpn + sRn;
	sumaPS = psRs + psRps + psRpn + psRn;
	sumaPN = pnRs + pnRps + pnRpn + pnRn;
	sumaN = nRs + nRps + nRpn + nRn;

	if (sumaS != 0) {
		sRs = sRs / sumaS;
		sRps = sRps / sumaS;
		sRpn = sRpn / sumaS;
		sRn = sRn / sumaS;
	}
	if (sumaPS != 0) {
		psRs = psRs / sumaPS;
		psRps = psRps / sumaPS;
		psRpn = psRpn / sumaPS;
		psRn = psRn / sumaPS;
	}
	if (sumaPN != 0) {
		pnRs = pnRs / sumaPN;
		pnRps = pnRps / sumaPN;
		pnRpn = pnRpn / sumaPN;
		pnRn = pnRn / sumaPN;
	}
	if (sumaN != 0) {
		nRs = nRs / sumaN;
		nRps = nRps / sumaN;
		nRpn = nRpn / sumaN;
		nRn = nRn / sumaN;
	}
	sumaS = sRs + sRps + sRpn + sRn;
	sumaPS = psRs + psRps + psRpn + psRn;
	sumaPN = pnRs + pnRps + pnRpn + pnRn;
	sumaN = nRs + nRps + nRpn + nRn;

	//INICIALIZAR VECTOR
	if (arrdias[dias - 1] == 0) { vector = new CVector((float)1, (float)0, (float)0, (float)0); }
	if (arrdias[dias - 1] == 1) { vector = new CVector((float)0, (float)1, (float)0, (float)0); }
	if (arrdias[dias - 1] == 2) { vector = new CVector((float)0, (float)0, (float)1, (float)0); }
	if (arrdias[dias - 1] == 3) { vector = new CVector((float)0, (float)0, (float)0, (float)1); }
}
void CCV::calSigVector(){
	vector->calVectorSig(sRs, sRps, sRpn, sRn, psRs, psRps, psRpn, psRn, pnRs, pnRps, pnRpn, pnRn, nRs, nRps, nRpn, nRn);
}
int CCV::getultimodia() { return arrdias[dias - 1]; }